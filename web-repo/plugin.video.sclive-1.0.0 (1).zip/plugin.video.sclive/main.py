import sys
import xbmcgui
import xbmcplugin

handle = int(sys.argv[1])


def run():
    xbmcplugin.setContent(handle, "videos")

    items = [
        ("Filmy", "movies"),
        ("Seriály", "tvshows"),
        ("Vyhledávání", "search"),
    ]

    for label, mode in items:
        list_item = xbmcgui.ListItem(label=label)
        url = f"{sys.argv[0]}?mode={mode}"
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


if __name__ == "__main__":
    run()